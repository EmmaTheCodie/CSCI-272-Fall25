#include <iostream>   // For input and output
#include <cstdlib>    // For rand() and srand()
#include <ctime>      // For seeding the random number generator

using namespace std;

// Game settings
int NUM_ROUNDS = 3;       // Number of game rounds
int EMOJI_COUNT = 6;      // Number of emojis in the game
int MAX_SPIN = 3;         // Maximum spins per round

// Array of emojis used in the slot machine
string emojis[6] = { "\U0001F34E", "\U0001F352", "\U0001F347", "\U0001F514", "\U0001F48E", "\U0001F340" };

// Array of powerup emojis
string powerups[6] = { "\U0001F501", "\U0001F522", "\u26D4", "\U0001F340", "\u267B\ufe0f", "\U0001F6E1" };

// Function to return a random number from 0 to max - 1
int randomInt(int max) {
    return rand() % max;
}

// Function that prints the instructions for the game
void instructions() {
    cout << "Welcome to the Emoji Slot Machine Game!" << endl;
    cout << "Match 3 emojis to win 50 points!" << endl;
    cout << "Match 2 emojis to win 20 points!" << endl;
    cout << "Use powerups to boost your chances!" << endl;
    cout << "Each player gets 3 rounds of up to 3 spins per round." << endl;
}

// Function to simulate a slot machine spin
// Returns the number of matching emojis (3, 2, or 0)
// If 'guaranteeMatch' is true, it guarantees at least a 2-match
int spinSlot(bool guaranteeMatch = false) {
    int indices[3];

    if (guaranteeMatch) {
        // Force at least 2 emojis to match
        int matchEmoji = randomInt(6);
        indices[0] = matchEmoji;
        indices[1] = matchEmoji;
        indices[2] = randomInt(6);

        // If all 3 match, it's a 3-match; else it's a 2-match
    } else {
        // Fully random spin
        for (int i = 0; i < 3; ++i) {
            indices[i] = randomInt(6);
        }
    }

    // Display the spin result
    cout << "Spin: ";
    for (int i = 0; i < 3; ++i) {
        cout << emojis[indices[i]] << " ";
    }
    cout << endl;

    // Evaluate the spin result
    if (indices[0] == indices[1] && indices[1] == indices[2]) {
        return 3;  // All match
    } else if (indices[0] == indices[1] || indices[1] == indices[2] || indices[0] == indices[2]) {
        return 2;  // Two match
    } else {
        return 0;  // No match
    }
}

// Function to apply a powerup effect based on the powerup ID
void applyPowerup(int powerupID, int& playerSpins, bool& luckySpin, bool& doublePoints, bool& blockOpponent) {
    if (powerupID == 0) {
        playerSpins += 1;            // Extra spin
    } else if (powerupID == 1) {
        doublePoints = true;         // Double points
    } else if (powerupID == 2) {
        blockOpponent = true;        // Block opponent (they lose one spin)
    } else if (powerupID == 3) {
        luckySpin = true;            // Lucky spin (guarantees 2 match)
    }
    // Powerups 4 and 5 (Re-roll and Block Lucky) are not yet implemented
}

int main() {
    // Seed the random number generator
    srand(time(0));

    // Show game instructions
    instructions();

    // Player scores
    int p1Score = 0, p2Score = 0;

    // Flags to block opponent's spins next round
    bool p1Block = false, p2Block = false;

    // Loop through each round
    for (int round = 1; round <= NUM_ROUNDS; ++round) {
        cout << "\n=== ROUND " << round << " ===\n";

        // --- Player 1's Turn ---
        int p1Spins = p1Block ? 2 : MAX_SPIN;  // If blocked, only 2 spins
        p1Block = false;                       // Reset block after applying
        bool p1Lucky = false, p1Double = false;

        cout << "Player 1's Turn:\n";
        for (int i = 0; i < p1Spins; ++i) {
            int match = spinSlot(p1Lucky);
            if (match == 3) {
                p1Score += p1Double ? 100 : 50;
            } else if (match == 2) {
                p1Score += p1Double ? 40 : 20;
            }
        }

        // Player 1 receives a random powerup
        int p1Power = randomInt(6);
        cout << "Player 1 gets powerup: " << powerups[p1Power] << endl;
        applyPowerup(p1Power, p1Spins, p1Lucky, p1Double, p2Block);

        // --- Player 2's Turn ---
        int p2Spins = p2Block ? 2 : MAX_SPIN;
        p2Block = false;
        bool p2Lucky = false, p2Double = false;

        cout << "Player 2's Turn:\n";
        for (int i = 0; i < p2Spins; ++i) {
            int match = spinSlot(p2Lucky);
            if (match == 3) {
                p2Score += p2Double ? 100 : 50;
            } else if (match == 2) {
                p2Score += p2Double ? 40 : 20;
            }
        }

        // Player 2 receives a random powerup
        int p2Power = randomInt(6);
        cout << "Player 2 gets powerup: " << powerups[p2Power] << endl;
        applyPowerup(p2Power, p2Spins, p2Lucky, p2Double, p1Block);
    }

    // --- End of Game: Show Final Scores ---
    cout << "\n=== GAME OVER ===\n";
    cout << "Player 1 Score: " << p1Score << endl;
    cout << "Player 2 Score: " << p2Score << endl;

    // Determine winner
    if (p1Score > p2Score) {
        cout << "Player 1 Wins!\n";
    } else if (p2Score > p1Score) {
        cout << "Player 2 Wins!\n";
    } else {
        cout << "It's a tie! Consider a tiebreaker round.\n";
    }

    return 0;
}
