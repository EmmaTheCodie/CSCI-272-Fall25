/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int n; // variable for natural num
    int i = 1; //has to equal 1 
    int total;
    cout<< "Please write what number you want the Natural numbers for.\n";
    cin>> n; 
    
    while (i <= n){  //while i is less than n 
        total = total +i; // add whatever i is to the var n
        ++i; // adds one to i 
    }
    
cout << total;
    return 0;
}