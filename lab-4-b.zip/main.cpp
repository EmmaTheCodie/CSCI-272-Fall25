/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int n;
    int i = 1;
    int total=1;
    cout<< "Please enter a number to find its factorial.\n";
    cin>> n; 
    
    
    while (i <= n){ //using while loop to calculate the factorial number 
        total = total *i; // multplies the total by 1 2 3 4 until it reaches the number the user put in 
        ++i;
    }
    
cout << total; //outputs the number 
    return 0;
}